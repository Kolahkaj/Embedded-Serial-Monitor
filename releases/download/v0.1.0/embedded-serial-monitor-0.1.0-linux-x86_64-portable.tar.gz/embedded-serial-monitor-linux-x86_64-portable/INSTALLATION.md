# Embedded Serial Monitor: Final Installation Guide

## Package selection

The final project archive contains installers and portable executables for both Windows architectures, plus native packages for Debian/Ubuntu amd64 and Arch Linux x86_64.

| Platform | Artifact | Recommended action |
|---|---|---|
| Windows 64-bit | `windows/embedded-serial-monitor-win64-setup.exe` | Run the installer. This is the correct choice for almost all current Windows PCs. |
| Windows 32-bit | `windows/embedded-serial-monitor-win32-setup.exe` | Run only on a 32-bit edition of Windows. |
| Windows portable | `windows/embedded-serial-monitor-win64.exe` or `win32.exe` | Copy to a folder and run directly; no installation is needed. |
| Debian/Ubuntu amd64 | `linux/embedded-serial-monitor_0.1.0_amd64.deb` | Install with `sudo apt install ./embedded-serial-monitor_0.1.0_amd64.deb`. |
| Arch Linux x86_64 | `linux/embedded-serial-monitor-0.1.0-1-x86_64.pkg.tar.zst` | Install with `sudo pacman -U ./embedded-serial-monitor-0.1.0-1-x86_64.pkg.tar.zst`. |
| Linux portable x86_64 | `linux/embedded-serial-monitor-0.1.0-linux-x86_64-portable.tar.gz` | Extract and run `./embedded-serial-monitor`; no package manager installation is needed. |

The Windows installers register Start Menu and desktop shortcuts and include an uninstaller. The Linux packages install the binary, desktop-menu entry, icon, license, and package metadata.

## Linux serial-port access

Access to USB/RS-232 serial adapters normally requires membership in a device-access group. On distributions that use the `dialout` group, run the following command and then sign out and back in:

```bash
sudo usermod -aG dialout "$USER"
```

## Direct connection modes

Each tab uses **Connect → Mode** to select **Serial**, **TCP**, or **UDP**. Serial mode presents device and electrical configuration. TCP and UDP mode present a host/bind address, port, and client/server role. A TCP or UDP server can bind to `0.0.0.0` to listen on all local interfaces; use `127.0.0.1` for local-only testing.

The separate **Network** page is a Serial Network Bridge. It is only applicable to physical Serial mode and forwards serial traffic to a distinct TCP or UDP endpoint. It is not needed for a direct TCP/UDP tab.

## Verify release files

The release directory contains `SHA256SUMS.txt`. Validate every platform artifact before installing:

```bash
sha256sum -c SHA256SUMS.txt
```

On Windows, compare the displayed SHA-256 value in an approved local checksum utility with the corresponding line in the manifest.
