# Embedded Serial Monitor

**Embedded Serial Monitor** is a native Rust desktop application for inspecting, transmitting, framing, decoding, plotting, exporting, and bridging serial traffic during authorized embedded-system development. This distribution includes complete source code, a Linux x86_64 GUI executable, and a Windows x64 GUI executable.

> **Safety notice.** BREAK injection, DTR/RTS control, fuzzing, repeated high-rate transmission, and network bridging can reset, destabilize, erase, or otherwise affect attached equipment. Use these features only on systems and networks you own or are explicitly authorized to test.

## Product workspace

The interface uses three focused workspace tabs. Port selection, sessions, export, pause, and help remain available above the workspace; port creation, serial-device refresh, connection, baud scanning, and appearance selection live in **Settings**.

| Tab | Purpose |
|---|---|
| **Main** | Responsive side-by-side live data and transmit/automation workspaces. Search, noise filtering, and clearing remain next to the packet stream. On narrow windows, the layout becomes a single safe vertical workspace. |
| **Settings** | Port management, serial connection, baud scan, appearance selection, framing, protocol decoding, electrical control, TCP/UDP bridge, display safety limits, colour rules, and export-format controls. |
| **Plotting** | Time-series and X/Y structured telemetry plots, non-destructive filters, frequency measurement, and FFT spectrum analysis. |

Every major workspace section includes an **ⓘ help icon** with focused in-place guidance. The default dark theme uses high-contrast status colours, deliberate spacing, visible scrollbar handles, and readable form controls; a light theme remains available in **Settings → Appearance**.

## Capabilities

| Area | Included functionality |
|---|---|
| **Connection** | Multiple serial-port tabs, custom baud rate, 5–8 data bits, 1–2 stop bits, parity, RTS/CTS or XON/XOFF flow control, port refresh, auto-reconnect, and printable-traffic baud scanning. |
| **Display** | Selective ASCII, HEX, octal, binary, decimal, and mixed `[HEX] ASCII` views; absolute, relative, or delta timestamps; search and hide regular expressions; bookmarks; light and dark themes; editable colour rules. |
| **Framing and decode** | Raw chunks, idle-timeout framing, start/end-byte framing, fixed-length framing, and built-in summaries for MODBUS RTU, NMEA 0183, DMX512, MIDI, and ASCII CAN-adapter frames. |
| **Transmit and automation** | ASCII or hex input, XOR-8, ADD-8, LRC, Modbus CRC-16, and CRC-32 appending, LF append, repeated send, packetized binary-file streaming, send history, regex-triggered responses, macros, BREAK, pin control, and random-frame fuzzing. |
| **Plotting and analysis** | Time-series and X/Y telemetry charts; raw, moving-average, median, and one-pole low-pass display filters; min/max/mean/RMS, rising-crossing frequency/period measurement, and Hann-windowed FFT spectrum analysis. |
| **Export and sessions** | Bounded in-memory records with CSV, JSON, or SQLite export; selectable HEX, ASCII, octal, binary, decimal, or mixed output; selectable all/RX/TX/bookmarked scope; portable JSON sessions preserving monitor configuration, bridge settings, logs, and send history. |
| **Network bridge** | Serial-to-TCP client/server and UDP endpoint modes. Serial RX bytes are forwarded to active peers, and received network bytes are sent to the selected serial worker. |

## Plotting structured records

The **Plotting** tab reads numeric field/value pairs from incoming RX records. The accepted input is a complete brace-delimited object with one or more comma-separated pairs.

```text
{temperature: 24.6, pressure: 101.3, rpm: 1250}
```

Incomplete objects are ignored rather than joined to later raw chunks. If a device can split an object across reads, use **Idle timeout** or **Start / end bytes** framing so the complete object reaches the plotter in one record. Names may contain letters, digits, underscore, hyphen, or period. Values must be finite decimal numbers.

| Control | Behavior |
|---|---|
| **Time series** | Draws every enabled field against elapsed capture time. |
| **X / Y** | Draws Y against X. Alternating messages use the most recently captured counterpart; send both fields in one object for synchronized measurements. |
| **Signal analysis** | Selects one field for non-destructive filtering, numerical measurements, and optional FFT spectrum display. |
| **History and Sample Hz** | Bound retained samples and structured-record capture rate independently of raw serial throughput. |
| **View controls** | Pause/resume plot capture, clear samples and fields, reset view, pan, wheel zoom, box zoom, automatic/manual Y bounds, and configurable line width. |

## High-throughput safeguards

Continuous traffic is handled through a bounded pipeline rather than one UI event per serial read. The serial worker batches input, limits its pending UI buffer to **256 KiB**, and reports bytes that must be shed to preserve responsiveness. The interface processes at most **48** queued receive events per frame, bounds incomplete framing accumulation to **1 MiB**, and renders no more than the newest **2,000** records.

The full in-memory history remains bounded by **RAM buffer MiB** in Settings. Display filters and colour rules are compiled once per rendered frame. Set **Lines/sec limit** to a nonzero value when representative display data is sufficient. These safeguards protect the application; configure device flow control separately when the target supports it.

## Quick start

### Linux

```bash
chmod +x embedded-serial-monitor
./embedded-serial-monitor
```

On many distributions, access to `/dev/ttyUSB*` or `/dev/ttyACM*` requires membership in the serial-device group.

### Windows

Extract the Windows x64 archive completely, then double-click `embedded-serial-monitor.exe`. Select a COM device, set the baud rate and framing, and choose **Connect**. The application is a native GUI executable and does not deliberately open a console window.

## Recommended workflow

In **Settings → Connection**, use **New connection** when you need another independent port configuration, click **Scan ports** after attaching a device, then select the serial device and enter its exact baud rate. Use **Auto baud scan** only when the device is actively transmitting, then confirm the result against known protocol behavior. Choose a framing mode before enabling a decoder: raw chunks suit terminal diagnostics, idle timeout suits gap-delimited UART packets, start/end bytes suit framed binary protocols, and fixed length suits constant-size telegrams.

Use **Main** for monitoring and transmission. Configure display representations, rate limits, memory budget, colour rules, and the TCP/UDP bridge in **Settings**. In the unified **Export format** section choose CSV, JSON, or SQLite; choose the exported byte representation; and choose all, RX, TX, or bookmarked records. Then use the single **Export** action in the top toolbar to save the selected port’s chosen record set. Use **Plotting** when firmware emits structured numerical telemetry in the documented `{name: value}` format.

## Macro language

The portable macro language is line-oriented and case-insensitive.

| Command | Meaning | Example |
|---|---|---|
| `SEND text` | Send the rest of the line as UTF-8 text. | `SEND AT+RST` |
| `SEND_HEX bytes` | Send hexadecimal bytes. | `SEND_HEX AA 55 01 00` |
| `DELAY ms` or `WAIT ms` | Wait between actions. | `DELAY 100` |
| `DTR_PULSE ms` | Pulse the DTR line. | `DTR_PULSE 50` |
| `BREAK ms` | Send a serial BREAK condition. | `BREAK 250` |
| `REPEAT n` … `END` | Repeat a group of commands. | `REPEAT 10` |

Macro sends are visible as **TX** records; DTR and BREAK actions appear as **SYS** records. The UI reports successful completion or actionable syntax and dispatch errors.

## Scope notes

| Requested extension | Status |
|---|---|
| **Passive sniffing of an already-open physical serial port** | Not included. A normal exclusive serial device cannot be read by a second process. Hardware UART tapping or a platform-specific virtual-port driver/proxy is required. |
| **Virtual COM-pair creation** | Not included because system virtual ports require a platform-specific driver or privileged service. |
| **Native SPI/I²C monitor** | Not included; serial and USB-CDC ports are supported directly. |
| **MQTT, WebSocket, HTTP dashboard, or browser API** | Not included. TCP/UDP bridge modes are retained for network integration. |
| **Command-line automation executable** | Not included in the final product; use the desktop application. |
| **Third-party native decoder loading** | Not included because native plugin loading requires a versioned ABI and trusted-plugin model. |

## Build from source

The project uses stable Rust. Linux desktop builds require the normal OpenGL, font, input, and udev development libraries for the host distribution.

```bash
cargo test
cargo run
cargo build --release
```

For Windows x64 cross-compilation from Linux, install the `x86_64-pc-windows-gnu` Rust target plus MinGW-w64 and run:

```bash
cargo build --release --target x86_64-pc-windows-gnu
```

The included `.cargo/config.toml` selects `x86_64-w64-mingw32-gcc` for that target. The packaged Windows executable is configured as a native GUI application.

## Validation performed

The final source is formatted, compile-checked, and tested before packaging. The automated suite passes **12 tests** covering hex parsing, checksums, framing, requested export-byte rendering, bounded filtering, structured-record parsing, X/Y value pairing, display filters, frequency measurement, FFT peak detection, and macro action/completion/error reporting. Optimized GUI binaries are produced for Linux x86_64 and Windows x64.

## Repository layout

```text
embedded-serial-monitor/
├── src/
│   ├── main.rs        # Native GUI, tabs, plotting, macros, and user workflows
│   ├── transport.rs   # Serial workers, batching, reconnect, pin control, TCP/UDP bridges
│   ├── engine.rs      # Formatting, bounded framing, checksums, decoding, exports, tests
│   └── types.rs       # Configuration, records, sessions, and worker event models
├── .cargo/config.toml # Windows MinGW cross-linker configuration
├── Cargo.toml
├── Cargo.lock
├── README.md
├── USER_MANUAL.md
├── RUST_DEVELOPER_AND_BUILD_GUIDE.md
├── LICENSE
├── THIRD_PARTY_NOTICES.md
└── LICENSES/
```

## License

The project source is provided under the MIT License in `LICENSE`. See `THIRD_PARTY_NOTICES.md` and `LICENSES/` for the bundled notices and license texts of dependencies.
